Array3d v(1,2,3), w(3,2,1);
cout << (v!=w) << endl;
